package entidades;


public class Retangulo extends Figura{
    @Override
    public void desenhar(){
        System.out.println("Pareço um tijolo.");
    }
}
