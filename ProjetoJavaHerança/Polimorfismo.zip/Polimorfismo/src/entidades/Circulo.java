
package entidades;

public class Circulo extends Figura{
    @Override
    public void desenhar(){
        System.out.println("Para me desenhar faça um movimento circular com o lápis no papel.");
    }
     
 
}
